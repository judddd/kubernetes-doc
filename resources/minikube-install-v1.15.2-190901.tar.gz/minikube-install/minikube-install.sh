export http_proxy=http://192.168.1.104:1087;export https_proxy=http://192.168.1.104:1087; # 注意两个都是http，不是https


minikube start --docker-env http_proxy=http://192.168.1.104:1087 --docker-env https_proxy=http://192.168.1.104:1087 --docker-env no_proxy=localhost,192.168.1.104,192.168.99.0/24 --log_dir=tmp --cpus 2 --memory 2048
