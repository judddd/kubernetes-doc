#!/bin/bash

echo "删除minikube虚拟机"
minikube delete

echo "删除kubectl"
rm -fr /usr/local/bin/kubectl

echo "卸载minikube"
rpm -e minikube

echo "删除virtualbox源"
rm -rf /etc/yum.repos.d/virtualbox.repo
yum -y remove VirtualBox-5.2 
yum -y remove gcc perl make kernel-devel xdg-utils 
