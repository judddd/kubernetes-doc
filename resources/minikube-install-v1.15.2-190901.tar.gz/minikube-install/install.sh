#!/bin/bash

echo "安装minikube"
rpm -ivh minikube-*.rpm

echo "配置virtualbox"
cp virtualbox.repo /etc/yum.repos.d/
yum -y install VirtualBox-5.2 
yum -y install gcc perl make kernel-devel   xdg-utils
rcvboxdrv setup
sleep 2

echo "安装kubectl"
cp kubectl /usr/local/bin/
chmod +x /usr/local/bin/kubectl
kubectl version
kubectl get nodes

sleep 2

echo "开始安装minikube"
sh minikube-install.sh

echo "验证"
minikube version

echo "安装dashboard"
minikube dashboard
minikube dashboard --url
